INSERT INTO producto (nombre, descripcion, unidades, costo, precio, categoria)
VALUES
	('Yerba Mate Pajarito', 'Menta 1kg', 5, 5000, 7000, 'Alimentos'),
	('Azucar Morena', '1kg', 5, 6500, 9000, 'Alimentos'),
	('Leche Entera Trebol', '1lt', 7, 8000, 10000, 'Alimentos');

INSERT INTO usuario (nombre, contrasenia, administrador)
VALUES
	('admin', 'admin', 1),
	('cpalacios', '2305', 1),
	('user1', '1234', 0),
	('user2', '1234', 1),
	('user3', '1234', 0);

