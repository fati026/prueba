/*
  En el paquete "modelo" se encuentran las clases que representan las entidades del dominio de la aplicación. 
*/
package modelo;

import java.util.List;

public class Cliente {
    private Integer id;
    private String nombre;
    private String apellido;
    private String correo_electronico;
    private String telefono;
    private String direccion;
    private Integer administrador;

    public Cliente() {
    }

    public Cliente(String nombre, String descripcion, String apellido, String costo, String correo_electronico) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo_electronico = correo_electronico;
        this.telefono = telefono;
        this.direccion = direccion;
        this.administrador = administrador;
    }
    
    public Cliente(Integer id, String nombre, String descripcion, String apellido, String costo, String correo_electronico, String telefono,String direccion,Integer administrador ) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo_electronico = correo_electronico;
        this.telefono = telefono;
        this.direccion = direccion;
        this.administrador = administrador;
    }

    public Integer getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getCorreo_electronico() {
        return correo_electronico;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getDireccion() {
        return direccion;
    }
    
    public Integer getAdministrador() {
        return administrador;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setCorreo_electronico(String correo_electronico) {
        this.correo_electronico = correo_electronico;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }   
    
    public void setAdministrador(Integer administrador) {
        this.administrador = administrador;
    }

    public Object getCategoria() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void add(List<Cliente> cliente) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
