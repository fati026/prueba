package controlador;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import modelo.Proveedor;
import modeloDAO.ProveedorDAO;

public class ControladorProveedores extends HttpServlet {

    private ProveedorDAO DaoProveedor;

    @Override
    public void init() throws ServletException {
        super.init();
        DaoProveedor = new ProveedorDAO(); // Inicialización del DAO en el método init
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        if (session.getAttribute("usuario") == null) {
            // El usuario no ha iniciado sesión, redirigir al inicio de sesión
            response.sendRedirect("index.jsp");
            return;
        }
        
        String accion = request.getParameter("accion");
        List<Proveedor> proveedores = new ArrayList<>();

        switch (accion) {
            case "listar":
                proveedores = DaoProveedor.getProveedores();
                request.setAttribute("Proveedores", proveedores);
                request.getRequestDispatcher("listadoProveedores.jsp").forward(request, response);
                break;
            case "nuevo":
                request.getRequestDispatcher("addProveedor.jsp").forward(request, response);
                break;
            case "Agregar":
                int resultado;
                String nombreProveedor = request.getParameter("txtNombreProveedor");
                String correoElectronico = request.getParameter("txtCorreoElectronico");
                String telefono = request.getParameter("txtTelefono");
                String direccion = request.getParameter("txtDireccion");
                Date fechaRegistro = null;
                try {
                    fechaRegistro = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("txtFechaRegistro"));
                } catch (ParseException e) {
                    System.err.println("Error al convertir la fecha: " + e);
                }
                Proveedor nuevoProveedor = new Proveedor(nombreProveedor, correoElectronico, telefono, direccion, fechaRegistro);
                resultado = DaoProveedor.add(nuevoProveedor);

                if (resultado != 0) {
                    request.setAttribute("config", "alert alert-success");
                    request.setAttribute("mensaje", "EL PROVEEDOR SE HA AGREGADO CON ÉXITO");
                } else {
                    request.setAttribute("config", "alert alert-danger");
                    request.setAttribute("mensaje", "NO SE HA PODIDO GUARDAR EL PROVEEDOR");
                }
                request.getRequestDispatcher("mensaje.jsp").forward(request, response);
                break;
            case "Editar":
                int idProveedor = Integer.valueOf(request.getParameter("id"));
                Proveedor proveedorEditar = DaoProveedor.getId(idProveedor);
                request.setAttribute("proveedor", proveedorEditar);
                request.getRequestDispatcher("editarProveedor.jsp").forward(request, response);
                break;
            case "Actualizar":
                int idProveedorActualizar = Integer.valueOf(request.getParameter("txtId"));
                String nombreActualizar = request.getParameter("txtNombre");
                String correoElectronicoActualizar = request.getParameter("txtCorreoElectronico");
                String telefonoActualizar = request.getParameter("txtTelefono");
                String direccionActualizar = request.getParameter("txtDireccion");
                Date fechaRegistroActualizar = null;
                try {
                    fechaRegistroActualizar = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("txtFechaRegistro"));
                } catch (ParseException e) {
                    System.err.println("Error al convertir la fecha: " + e);
                }
                Proveedor proveedorActualizado = new Proveedor(nombreActualizar, correoElectronicoActualizar, telefonoActualizar, direccionActualizar, fechaRegistroActualizar);
                int respuestaActualizar = DaoProveedor.update(proveedorActualizado);

                if (respuestaActualizar != 0) {
                    request.setAttribute("config", "alert alert-success");
                    request.setAttribute("mensaje", "EL PROVEEDOR SE HA ACTUALIZADO CON ÉXITO");
                } else {
                    request.setAttribute("config", "alert alert-danger");
                    request.setAttribute("mensaje", "NO SE HA PODIDO ACTUALIZAR EL PROVEEDOR");
                }
                request.getRequestDispatcher("mensaje.jsp").forward(request, response);
                break;
            case "Eliminar":
                int idProveedorEliminar = Integer.valueOf(request.getParameter("id"));
                int respuestaEliminar = DaoProveedor.delete(idProveedorEliminar);
                if (respuestaEliminar != 0) {
                    request.setAttribute("config", "alert alert-warning");
                    request.setAttribute("mensaje", "EL PROVEEDOR SE HA ELIMINADO CON ÉXITO");
                } else {
                    request.setAttribute("config", "alert alert-danger");
                    request.setAttribute("mensaje", "NO SE HA PODIDO ELIMINAR EL PROVEEDOR");
                }
                request.getRequestDispatcher("mensaje.jsp").forward(request, response);
                break;
            default:
                throw new AssertionError();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
