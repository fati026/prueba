package controlador;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ValidarServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String nombreUsuario = request.getParameter("txtNombre");
        String contrasenia = request.getParameter("txtContrasenia");
        
        // Verificar las credenciales (aquí debes incluir tu lógica de autenticación)
        if (nombreUsuario.equals("usuario") && contrasenia.equals("contraseña")) {
            // Autenticación exitosa
            HttpSession session = request.getSession();
            session.setAttribute("usuario", nombreUsuario);
            
            // Redirigir al controlador de proveedores
            response.sendRedirect(request.getContextPath() + "/ControladorProveedores?accion=listar");
        } else {
            // Credenciales incorrectas, redirigir de vuelta al inicio de sesión con mensaje de error
            response.sendRedirect("index.jsp?error=1");
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
