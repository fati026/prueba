package controlador;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import modelo.Auditoria;
import modelo.Cliente;
import modelo.Usuario;
import modeloDAO.AuditoriaDAO;
import modeloDAO.ClienteDAO;

public class ControladorClientes extends HttpServlet {

    ClienteDAO DaoCliente = new ClienteDAO();

    private List<Cliente> FiltarPorCategoria(List<Cliente> clientes, String categoriaAFiltrar) {
        List<Cliente> clientesFiltrados = new ArrayList<>();
        for (Cliente cliente : clientes) {
            if (Objects.equals(cliente.getCategoria(), categoriaAFiltrar)) {
                clientesFiltrados.add(cliente);
            }
        }
        return clientesFiltrados;
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");
        List<Cliente> clientes = new ArrayList<>();
        HttpSession session = request.getSession();
        String nombreUsuario = (String) session.getAttribute("nombreUsuario");
        Integer idUsuario = (Integer) session.getAttribute("idUsuario");
    System.out.println ("llego hasta aca 1");
        switch (accion) {
            case "listar":
                clientes = DaoCliente.getClientes();
                Collections.reverse(clientes);
               // String categoriaAFiltrar = request.getParameter("txtCategoria");
               /* if (Objects.equals(categoriaAFiltrar, "Todos")) {
                    request.setAttribute("Clientes", clientes);
                } else {
                    clientes = FiltarPorCategoria(clientes, categoriaAFiltrar);
                    request.setAttribute("Clientes", clientes);
                }*/
                System.out.println ("llego hasta aca 2");
                request.getRequestDispatcher("listadoCliente.jsp").forward(request, response);
                break;
            case "nuevo":
                request.getRequestDispatcher("addCliente.jsp").forward(request, response);
                break;
            case "Agregar":
                String nombre = request.getParameter("txtNombre");
                String apellido = request.getParameter("txtApellido");
                String correo_electronico = request.getParameter("txtCorreo_electronico");
                String telefono = request.getParameter("txtTelefono");
                String direccion = request.getParameter("txtDireccion");
                Cliente cliente = new Cliente(nombre, apellido, correo_electronico, telefono, direccion);
                int resultado = DaoCliente.add(cliente);
                break;
            case "Editar":
                int id = Integer.valueOf(request.getParameter("id"));
                Cliente p = DaoCliente.getId(id);
                request.setAttribute("cliente", p);
                request.getRequestDispatcher("editarCliente.jsp").forward(request, response);
                break;
            case "Actualizar":
                int idCliente = Integer.valueOf(request.getParameter("txtId"));
                Cliente clienteAEditar = DaoCliente.getId(idCliente);
                String nombreActualizado = request.getParameter("txtNombre");
                String apellidoActualizado = request.getParameter("txtApellido");
                String correoElectronicoActualizado = request.getParameter("txtCorreo_electronico");
                String telefonoActualizado = request.getParameter("txtTelefono");
                String direccionActualizada = request.getParameter("txtDireccion");
                Cliente clienteActualizado = new Cliente(nombreActualizado, apellidoActualizado, correoElectronicoActualizado, telefonoActualizado, direccionActualizada);
                int respuesta = DaoCliente.update(clienteActualizado);
                break;
            case "Delete":
                int idClienteABorrar = Integer.valueOf(request.getParameter("id"));
                Cliente clienteABorrar = DaoCliente.getId(idClienteABorrar);
                int res = DaoCliente.delete(idClienteABorrar);
            default:
                throw new AssertionError();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
