package modeloDAO;

import config.Conexion;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.Proveedor;

public class ProveedorDAO implements InterfazProveedorDAO {

    @Override
    public List<Proveedor> getProveedores() {
        List<Proveedor> proveedores = new ArrayList<>();
        String sql = "SELECT * FROM proveedores;";
        try (PreparedStatement ps = Conexion.Conectar().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Proveedor proveedor = new Proveedor();
                proveedor.setId(rs.getInt("id"));
                proveedor.setNombreProveedor(rs.getString("nombre_proveedor"));
                proveedor.setCorreoElectronico(rs.getString("correo_electronico"));
                proveedor.setTelefono(rs.getString("telefono"));
                proveedor.setDireccion(rs.getString("direccion"));
                proveedores.add(proveedor);
            }
        } catch (SQLException e) {
            System.err.println("Error: " + e);
        } finally {
            Conexion.cerrarConexion();
        }

        return proveedores;
    }

    @Override
    public Proveedor getProveedor(String nombre) {
        String sql = "SELECT * FROM proveedores WHERE nombre_proveedor = ?;";
        Proveedor proveedor = new Proveedor();
        try (PreparedStatement ps = Conexion.Conectar().prepareStatement(sql)) {
            ps.setString(1, nombre);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    proveedor.setId(rs.getInt("id"));
                    proveedor.setNombreProveedor(rs.getString("nombre_proveedor"));
                    proveedor.setCorreoElectronico(rs.getString("correo_electronico"));
                    proveedor.setTelefono(rs.getString("telefono"));
                    proveedor.setDireccion(rs.getString("direccion"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error: " + e);
        } finally {
            Conexion.cerrarConexion();
        }

        return proveedor;
    }

    @Override
    public Proveedor getProveedor(String nombre, String contrasenia) {
        String sql = "SELECT * FROM proveedores WHERE nombre_proveedor = ? AND contrasenia = ?;";
        Proveedor proveedor = null;
        try (PreparedStatement ps = Conexion.Conectar().prepareStatement(sql)) {
            ps.setString(1, nombre);
            ps.setString(2, contrasenia);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    proveedor = new Proveedor();
                    proveedor.setId(rs.getInt("id"));
                    proveedor.setNombreProveedor(rs.getString("nombre_proveedor"));
                    proveedor.setCorreoElectronico(rs.getString("correo_electronico"));
                    proveedor.setTelefono(rs.getString("telefono"));
                    proveedor.setDireccion(rs.getString("direccion"));
                    proveedor.setFechaRegistro(rs.getDate("fecha_registro"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error: " + e);
        } finally {
            Conexion.cerrarConexion();
        }

        return proveedor;
    }

    @Override
    public Proveedor getId(int id) {
        String sql = "SELECT * FROM proveedores WHERE id = ?;";
        Proveedor proveedor = new Proveedor();
        try (PreparedStatement ps = Conexion.Conectar().prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    proveedor.setId(rs.getInt("id"));
                    proveedor.setNombreProveedor(rs.getString("nombre_proveedor"));
                    proveedor.setCorreoElectronico(rs.getString("correo_electronico"));
                    proveedor.setTelefono(rs.getString("telefono"));
                    proveedor.setDireccion(rs.getString("direccion"));
                    proveedor.setFechaRegistro(rs.getDate("fecha_registro"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error: " + e);
        } finally {
            Conexion.cerrarConexion();
        }

        return proveedor;
    }

    @Override
    public int add(Proveedor proveedor) {
        int resultado = 0;
        String sql = "INSERT INTO proveedores(nombre_proveedor, correo_electronico, telefono, direccion, fecha_registro) VALUES (?, ?, ?, ?, ?);";
        try (PreparedStatement ps = Conexion.Conectar().prepareStatement(sql)) {
            ps.setString(1, proveedor.getNombreProveedor());
            ps.setString(2, proveedor.getCorreoElectronico());
            ps.setString(3, proveedor.getTelefono());
            ps.setString(4, proveedor.getDireccion());
            ps.setDate(5, proveedor.getFechaRegistro());
            resultado = ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error al agregar en la base de datos" + e);
        } finally {
            Conexion.cerrarConexion();
        }

        return resultado;
    }

    @Override
    public int update(Proveedor proveedor) {
        int resultado = 0;
        String sql = "UPDATE proveedores SET nombre_proveedor = ?, correo_electronico = ?, telefono = ?, direccion = ?, fecha_registro = ? WHERE id = ?;";
        try (PreparedStatement ps = Conexion.Conectar().prepareStatement(sql)) {
            ps.setString(1, proveedor.getNombreProveedor());
            ps.setString(2, proveedor.getCorreoElectronico());
            ps.setString(3, proveedor.getTelefono());
            ps.setString(4, proveedor.getDireccion());
            ps.setDate(5, proveedor.getFechaRegistro());
            ps.setInt(6, proveedor.getId());
            resultado = ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error al actualizar en la base de datos" + e);
        } finally {
            Conexion.cerrarConexion();
        }

        return resultado;
    }

    @Override
    public int delete(int id) {
        int resultado = 0;
        String sql = "DELETE FROM proveedores WHERE id = ?;";
        try (PreparedStatement ps = Conexion.Conectar().prepareStatement(sql)) {
            ps.setInt(1, id);
            resultado = ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Ha ocurrido un error durante el borrado" + e);
        } finally {
            Conexion.cerrarConexion();
        }

        return resultado;
    }
}
