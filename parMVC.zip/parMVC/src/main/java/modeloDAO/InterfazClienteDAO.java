/*
  En el paquete "modeloDAO" concentra a las clases que implementan el patrón DAO (Data Access Object). 
  Estas clases se utilizan para interactuar con la capa de persistencia de datos.
*/

/*
  En el paquete "modeloDAO" concentra a las clases que implementan el patrón DAO (Data Access Object). 
  Estas clases se utilizan para interactuar con la capa de persistencia de datos.
*/
package modeloDAO;

import java.util.List;
import modelo.Cliente;

public interface InterfazClienteDAO {
    public List<Cliente> getClientes();
    public Cliente getId(int id);
    public int add(Cliente cliente);
    public int update(Cliente producto);
    public int delete(int id);
}
