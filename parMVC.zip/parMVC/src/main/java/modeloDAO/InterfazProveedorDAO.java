/*
  En el paquete "modeloDAO" concentra a las clases que implementan el patrón DAO (Data Access Object). 
  Estas clases se utilizan para interactuar con la capa de persistencia de datos.
*/

/*
  En el paquete "modeloDAO" concentra a las clases que implementan el patrón DAO (Data Access Object). 
  Estas clases se utilizan para interactuar con la capa de persistencia de datos.
*/
package modeloDAO;

import java.util.List;
import modelo.Proveedor;

public interface InterfazProveedorDAO {
    public List<Proveedor> getProveedores();
    public Proveedor getId(int id);
    public Proveedor getProveedor(String proveedor);
    public Proveedor getProveedor(String proveedor, String contrasenia);
    public int add(Proveedor proveedor);
    public int update(Proveedor proveedor);
    public int delete(int id);
}
